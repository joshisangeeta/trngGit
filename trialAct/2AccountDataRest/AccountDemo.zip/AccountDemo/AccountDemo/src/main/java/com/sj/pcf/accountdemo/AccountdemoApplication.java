package com.sj.pcf.accountdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountdemoApplication.class, args);
	}

}
